from flask import Flask, jsonify
from flask_cors import CORS
from pymongo import MongoClient

app = Flask(__name__)
# Habilitar CORS
CORS(app)

# Conexión a MongoDB Atlas
client = MongoClient("mongodb+srv://ramongo:LeoyDem01!_@cluster0.zbeo28o.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0")
db = client.get_database('test')  # Cambia 'test' por el nombre de tu base de datos si es diferente
usuarios_collection = db.usuarios

@app.route('/usuarios', methods=['GET'])
def get_usuarios():
    usuarios = list(usuarios_collection.find({}, {'_id': 0}))
    return jsonify(usuarios)

if __name__ == '__main__':
    app.run(debug=True)
    